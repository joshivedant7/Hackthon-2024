import 'package:flutter/material.dart';
import 'pages/fifth_page.dart';
import 'pages/first_page.dart';
import 'pages/home_screen.dart';


class HomePage extends StatelessWidget {
    const HomePage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          centerTitle: true,
          backgroundColor: Colors.black,
          title: Text('DataBase HUB',
          style: TextStyle(fontSize: 40, fontWeight: FontWeight.bold),
          ),
        ),
        drawer: Drawer(
          child: Container(
            color: Colors.grey,
            child: ListView(
            children: [
              DrawerHeader(
                child: Center(
                  child: Text(
                    'OPTIONS',
                    style: TextStyle(fontSize: 35, fontWeight: FontWeight.bold),

                  ),
                ),
              ),
              ListTile(
                leading: Icon(Icons.currency_rupee_rounded),
                title: Text(
                  'Transaction History',
                  style: TextStyle(fontSize: 20),
                ),
                onTap: () {
                  Navigator.of(context).push(
                      MaterialPageRoute(builder: (context) => FirstPage()));
                },
              ),
              ListTile(
                leading: Icon(Icons.bike_scooter),
                title: Text(
                  'Petrol Expenses',
                  style: TextStyle(fontSize: 20),
                ),
                onTap: () {
                  Navigator.of(context).push(
                      MaterialPageRoute(builder: (context) => HomeScreen()));
                },
              ),
              
              
              ListTile(
                leading: Icon(Icons.auto_graph),
                title: Text(
                  'Progress Report',
                  style: TextStyle(fontSize: 20),
                ),
                onTap: () {
                  Navigator.of(context).push(
                      MaterialPageRoute(builder: (context) => FifthPage()));
                },
              ),
            ],
          ),
        ),
        ),
      );
  }
}

FifthPage() {
}
